This project includes two case studies: LRE and GasAnalysis.

The RoboChart model is provied as EMF models.

The transformation rule is in the folder of 'Transformation rule'. Both cases of LRE and GasAnalysis use the transformation rules in this folder.

The verificaiton result from Isbelle/HOL is under the direction of 'theory generatio for XX/ xx verificaiton'.